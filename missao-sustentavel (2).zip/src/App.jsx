import React, { useState } from "react";

// Missão Sustentável – Caminho até 2025
// App.jsx — componente React pronto para colar no CodeSandbox (src/App.jsx)

export default function App() {
  const years = [2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025];

  const events = [
    { text: "Crise hídrica local", impact: -2 },
    { text: "Incentivo a energias renováveis", impact: +3 },
    { text: "Campanha de reciclagem na cidade", impact: +2 },
    { text: "Perda de biodiversidade em região próxima", impact: -3 },
    { text: "Adoção de transporte público elétrico", impact: +3 },
    { text: "Chuvas atípicas afetam colheitas", impact: -2 },
    { text: "Startups verdes recebem investimento", impact: +2 },
    { text: "Aumento do consumo de plástico", impact: -2 },
    { text: "Projeto de restauração urbana concluído", impact: +3 },
    { text: "Meta 2025: grandes decisões!", impact: 0 }
  ];

  const actions = [
    { id: "plant", label: "Plantar árvores", score: 2 },
    { id: "bike", label: "Optar por bicicleta", score: 1 },
    { id: "solar", label: "Instalar painéis solares", score: 3 },
    { id: "reduce", label: "Reduzir plástico", score: 2 }
  ];

  const [position, setPosition] = useState(0);
  const [score, setScore] = useState(0);
  const [history, setHistory] = useState([]);
  const [message, setMessage] = useState(
    "Bem-vindo à Missão Sustentável — Caminho até 2025! Escolha ações e enfrente eventos para alcançar metas." 
  );
  const [gameOver, setGameOver] = useState(false);

  function moveNext() {
    if (gameOver) return;
    const nextPos = Math.min(position + 1, years.length - 1);
    const event = events[nextPos];
    const eventImpact = event ? event.impact : 0;

    // aplicar impacto aleatório leve (variabilidade)
    const randomVariation = Math.floor(Math.random() * 3) - 1; // -1,0,1
    const totalEventImpact = eventImpact + randomVariation;

    const newScore = Math.max(0, score + totalEventImpact);
    setScore(newScore);
    setHistory([
      ...history,
      { year: years[nextPos], type: "evento", text: event.text, impact: totalEventImpact }
    ]);
    setPosition(nextPos);
    setMessage(`Ano ${years[nextPos]} — Evento: ${event.text} (impacto ${totalEventImpact >= 0 ? '+' : ''}${totalEventImpact})`);

    if (nextPos === years.length - 1) {
      endGame(newScore);
    }
  }

  function performAction(actionId) {
    if (gameOver) return;
    const action = actions.find(a => a.id === actionId);
    if (!action) return;
    const newScore = score + action.score;
    setScore(newScore);
    setHistory([
      ...history,
      { year: years[position], type: "acao", text: action.label, impact: action.score }
    ]);
    setMessage(`Você escolheu: ${action.label} (+${action.score} pontos)`);
  }

  function endGame(finalScore) {
    setGameOver(true);
    let grade = "Participante";
    if (finalScore >= 18) grade = "Campeão Sustentável";
    else if (finalScore >= 12) grade = "Defensor Verde";
    else if (finalScore >= 6) grade = "Agente Local";
    else grade = "Aprendiz";

    setMessage(`Fim da jornada (2025). Pontuação: ${finalScore}. Classificação: ${grade}`);
  }

  function resetGame() {
    setPosition(0);
    setScore(0);
    setHistory([]);
    setMessage("Reiniciado! Boa sorte na nova missão — Caminho até 2025.");
    setGameOver(false);
  }

  // small UI styles (inline para facilitar colagem no CodeSandbox)
  const styles = {
    wrapper: {
      fontFamily: "Inter, Arial, sans-serif",
      maxWidth: 980,
      margin: "18px auto",
      padding: 18,
      borderRadius: 12,
      boxShadow: "0 6px 18px rgba(0,0,0,0.08)"
    },
    header: { display: "flex", justifyContent: "space-between", alignItems: "center" },
    board: { display: "flex", gap: 8, marginTop: 12, overflowX: "auto" },
    tile: isActive => ({
      minWidth: 92,
      padding: 10,
      borderRadius: 8,
      background: isActive ? "linear-gradient(135deg,#1e9b73,#2acf89)" : "#f3f6f9",
      color: isActive ? "white" : "#0f1724",
      textAlign: "center",
      boxShadow: isActive ? "0 6px 18px rgba(46, 204, 113, 0.2)" : "none"
    }),
    controls: { marginTop: 14, display: "flex", gap: 8, flexWrap: "wrap" },
    actionBtn: { padding: "10px 14px", borderRadius: 8, border: "1px solid #d1d5db", cursor: "pointer", background: "white" },
    nextBtn: { padding: "10px 16px", borderRadius: 8, cursor: "pointer", border: "none", background: "#2563eb", color: "white" },
    small: { fontSize: 13, color: "#374151" },
    history: { marginTop: 12, maxHeight: 220, overflow: "auto", padding: 8, borderRadius: 8, background: "#ffffff" }
  };

  return (
    <div style={styles.wrapper}>
      <div style={styles.header}>
        <h1>Missão Sustentável — Caminho até 2025</h1>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontWeight: 700, fontSize: 18 }}>{score} pts</div>
          <div style={styles.small}>Ano atual: {years[position]}</div>
        </div>
      </div>

      <p style={{ marginTop: 8 }}>{message}</p>

      <div style={styles.board} role="list">
        {years.map((y, i) => (
          <div key={y} style={styles.tile(i === position)} role="listitem">
            <div style={{ fontSize: 14, fontWeight: 700 }}>{y}</div>
            <div style={{ marginTop: 8, fontSize: 12 }}>{events[i].text}</div>
            {i === years.length - 1 && <div style={{ marginTop: 8, fontSize: 12 }}>🏁</div>}
          </div>
        ))}
      </div>

      <div style={styles.controls}>
        <div>
          <button onClick={moveNext} style={styles.nextBtn} disabled={gameOver || position === years.length - 1}>
            Avançar ano ▶
          </button>
        </div>

        <div>
          {actions.map(a => (
            <button key={a.id} onClick={() => performAction(a.id)} style={styles.actionBtn} disabled={gameOver}>
              {a.label} (+{a.score})
            </button>
          ))}
        </div>

        <div>
          <button onClick={resetGame} style={{ ...styles.actionBtn }}>
            Reiniciar
          </button>
        </div>
      </div>

      <div style={styles.history}>
        <strong>Registro da missão</strong>
        {history.length === 0 && <div style={{ marginTop: 8 }}>Nenhuma ação registrada — comece a jogar.</div>}
        <ul style={{ marginTop: 8 }}>
          {history.map((h, idx) => (
            <li key={idx} style={{ marginBottom: 6 }}>
              <strong>{h.year}:</strong> {h.type === "acao" ? "Ação -" : "Evento -"} {h.text} ({h.impact >= 0 ? '+' : ''}{h.impact})
            </li>
          ))}
        </ul>
      </div>

      <footer style={{ marginTop: 12, fontSize: 13, color: "#6b7280" }}>
        Dica: combine ações (plantar, reduzir plástico, energia solar) para aumentar suas chances de obter uma classificação alta em 2025.
      </footer>
    </div>
  );
}
